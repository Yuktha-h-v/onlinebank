-- MySqlBackup.NET 2.0.9.2
-- Dump Time: 2017-04-24 08:40:28
-- --------------------------------------
-- Server version 5.7.17-log MySQL Community Server (GPL)

-- 
-- Create schema bank3
-- 

CREATE DATABASE IF NOT EXISTS `bank3` /*!40100 DEFAULT CHARACTER SET utf8 */;
Use `bank3`;



/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- 
-- Definition of accounts
-- 

DROP TABLE IF EXISTS `accounts`;
CREATE TABLE IF NOT EXISTS `accounts` (
  `account_id` int(10) NOT NULL AUTO_INCREMENT,
  `account_balance` decimal(6,2) NOT NULL,
  `account_type` varchar(20) NOT NULL,
  `customer_id` int(10) NOT NULL,
  PRIMARY KEY (`account_id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `accounts_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table accounts
-- 

/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts`(`account_id`,`account_balance`,`account_type`,`customer_id`) VALUES
(100,9999.99,'current',102),
(101,35.15,'current',103),
(114,8980.99,'Current',101),
(116,1000.00,'Saving',101);
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;

-- 
-- Definition of customers
-- 

DROP TABLE IF EXISTS `customers`;
CREATE TABLE IF NOT EXISTS `customers` (
  `customer_id` int(10) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(60) NOT NULL,
  `lastname` varchar(60) NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `user` varchar(60) NOT NULL,
  `password` varchar(16) NOT NULL,
  `address` varchar(70) NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table customers
-- 

/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers`(`customer_id`,`firstname`,`lastname`,`date_of_birth`,`email`,`user`,`password`,`address`) VALUES
(101,'Carlos','Amaro','0001-01-01 00:00:00','amaro80@gm','amaro80','carlos01','bayside'),
(102,'Mariah','Sonja','2005-11-08','mariahsonja@hotmail.com','mariah','mariah','city center'),
(103,'Olga','Minguett','1987-10-23','olgaminguett@gmail.com','olga01','olga','anything');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;

-- 
-- Definition of transactions
-- 

DROP TABLE IF EXISTS `transactions`;
CREATE TABLE IF NOT EXISTS `transactions` (
  `transaction_id` int(10) NOT NULL AUTO_INCREMENT,
  `customer_id_to` int(10) DEFAULT NULL,
  `account_id_to` int(10) DEFAULT NULL,
  `transaction_type` varchar(15) NOT NULL,
  `amount` decimal(6,2) NOT NULL,
  `customer_id` int(10) NOT NULL,
  `account_id` int(10) NOT NULL,
  `description` varchar(70) NOT NULL,
  PRIMARY KEY (`transaction_id`),
  KEY `customer_id` (`customer_id`),
  KEY `account_id` (`account_id`),
  CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`),
  CONSTRAINT `transactions_ibfk_2` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`account_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table transactions
-- 

/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions`(`transaction_id`,`customer_id_to`,`account_id_to`,`transaction_type`,`amount`,`customer_id`,`account_id`,`description`) VALUES
(1,101,116,'Transfer',100.00,101,114,'money'),
(2,101,116,'Transfer',1000.00,101,114,'money'),
(3,NULL,NULL,'Lodgement',100.00,101,114,'money'),
(4,NULL,NULL,'Withdraw',119.00,101,114,'withdraw');
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;


/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;


-- Dump completed on 2017-04-24 08:40:29
-- Total time: 0:0:0:0:218 (d:h:m:s:ms)
